//Afra Lintang 2311102258

package main

import (
	"fmt"
	"sort"
)

const nMax = 7919

type Buku struct {
	id         string
	judul      string
	penulis    string
	penerbit   string
	eksemplar  int
	tahun      int
	rating     int
}

type daftarbuku struct {
	Pustaka  []Buku
	nPustaka int
}

func DaftarkanBuku(pustaka *daftarbuku, n int) {
	pustaka.nPustaka = n
	pustaka.Pustaka = make([]Buku, n)
	for i := 0; i < n; i++ {
		fmt.Printf("Masukkan data buku ke-%d\n", i+1)
		fmt.Print("ID : ")
		fmt.Scan(&pustaka.Pustaka[i].id)
		fmt.Print("Judul : ")
		fmt.Scan(&pustaka.Pustaka[i].judul)
		fmt.Print("Penulis : ")
		fmt.Scan(&pustaka.Pustaka[i].penulis)
		fmt.Print("Penerbit : ")
		fmt.Scan(&pustaka.Pustaka[i].penerbit)
		fmt.Print("Eksemplar : ")
		fmt.Scan(&pustaka.Pustaka[i].eksemplar)
		fmt.Print("Tahun : ")
		fmt.Scan(&pustaka.Pustaka[i].tahun)
		fmt.Print("Rating : ")
		fmt.Scan(&pustaka.Pustaka[i].rating)
	}
}

func CetakFavorit(pustaka daftarbuku, n int) {
	sort.Slice(pustaka.Pustaka, func(i, j int) bool {
		return pustaka.Pustaka[i].rating > pustaka.Pustaka[j].rating
	})
	for i := 0; i < n; i++ {
		fmt.Printf("Judul: %s, Penulis: %s, Penerbit: %s, Tahun: %d\n",
			pustaka.Pustaka[i].judul, pustaka.Pustaka[i].penulis,
			pustaka.Pustaka[i].penerbit, pustaka.Pustaka[i].tahun)
	}
}

func UrutanBuku(pustaka *daftarbuku, n int) {
	sort.Slice(pustaka.Pustaka, func(i, j int) bool {
		return pustaka.Pustaka[i].rating > pustaka.Pustaka[j].rating
	})
}

func Cetak5Terbaru(pustaka daftarbuku, n int) {
	for i := 0; i < 5 && i < n; i++ {
		fmt.Printf("Judul: %s, Rating: %d\n", pustaka.Pustaka[i].judul, pustaka.Pustaka[i].rating)
	}
}

func CariBuku(pustaka daftarbuku, n int, r int) {
	idx := sort.Search(n, func(i int) bool {
		return pustaka.Pustaka[i].rating <= r
	})
	if idx < n && pustaka.Pustaka[idx].rating == r {
		buku := pustaka.Pustaka[idx]
		fmt.Printf("Buku ditemukan: Judul: %s, Penulis: %s, Penerbit: %s, Eksemplar: %d, Tahun: %d, Rating: %d\n",
			buku.judul, buku.penulis, buku.penerbit, buku.eksemplar, buku.tahun, buku.rating)
	} else {
		fmt.Println("Tidak ada buku dengan rating seperti itu.")
	}
}

func main() {
	var pustaka daftarbuku
	var n, r int

	fmt.Print("Masukkan jumlah buku: ")
	fmt.Scan(&n)

	DaftarkanBuku(&pustaka, n)

	fmt.Println("Daftar buku terfavorit:")
	CetakFavorit(pustaka, n)

	UrutanBuku(&pustaka, n)

	fmt.Println("Cetak 5 buku terbaru:")
	Cetak5Terbaru(pustaka, n)

	fmt.Print("Masukkan rating buku yang dicari: ")
	fmt.Scan(&r)

	CariBuku(pustaka, n, r)
}
