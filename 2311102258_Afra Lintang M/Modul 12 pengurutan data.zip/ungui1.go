//Afra Lintang 2311102258

package main  

import (  
	"fmt"  
	"sort"  
)  

func main() {  
	var n int  
	fmt.Print("Masukkan jumlah daerah kerabat(n) : ")  
	fmt.Scan(&n)  

	for daerah := 1; daerah <= n; daerah++ {  
		var m int  
		fmt.Printf("\nMasukkan jumlah nomor rumah kerabat untuk daerah %d : ", daerah)  
		fmt.Scan(&m)  

		arr := make([]int, m)  
		fmt.Printf("masukkan %d nomor rumah kerabat : ", m)  
		for i := 0; i < m; i++ {  
			fmt.Scan(&arr[i])  
		}  

		sort.Ints(arr)  
 
		var oddNums, evenNums []int  
		for _, num := range arr {  
			if num%2 == 0 {  
				evenNums = append(evenNums, num)  
			} else {  
				oddNums = append(oddNums, num)  
			}  
		}  
 
		fmt.Printf("nomor rumah ganjil terurut untuk daerah %d : ", daerah)  
		for _, num := range oddNums {  
			fmt.Printf("%d ", num)  
		}  
		fmt.Println()  

		fmt.Printf("nomor rumah genap terurut untuk daerah %d : ", daerah)  
		sort.Sort(sort.Reverse(sort.IntSlice(evenNums)))  
		for _, num := range evenNums {  
			fmt.Printf("%d ", num)  
		}  
		fmt.Println()  
	}  
}