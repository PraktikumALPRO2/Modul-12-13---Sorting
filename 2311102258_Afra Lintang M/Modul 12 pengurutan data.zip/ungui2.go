//Afra Lintang 2311102258

package main  

import (  
	"fmt"  
	"sort"  
)  

func main() {  
	var num int  
	var data []int  

	for {  
		fmt.Scan(&num)  
		if num == -5313 {  
			break  
		}  
		if num == 0 {  
			
			n := len(data)  
			sort.Ints(data)  
			median := data[n/2]  
			if n%2 == 0 {  
				median = (data[n/2-1] + data[n/2]) / 2  
			}  
			fmt.Println(median)  
		} else {  
			data = append(data, num)  
		}  
	}  
}