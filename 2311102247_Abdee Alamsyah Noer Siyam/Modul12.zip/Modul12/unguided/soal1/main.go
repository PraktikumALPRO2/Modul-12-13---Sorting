package main

import "fmt"


func selectionSort(arr []int, asc bool) {
	n := len(arr)
	for i := 0; i < n-1; i++ {
		targetIdx := i
		for j := i + 1; j < n; j++ {
			if (asc && arr[j] < arr[targetIdx]) || (!asc && arr[j] > arr[targetIdx]) {
				targetIdx = j
			}
		}
		arr[i], arr[targetIdx] = arr[targetIdx], arr[i]
	}
}

func main() {
	var n int
	fmt.Scan(&n)

	rumah := make([]string, n)

	for i := 0; i < n; i++ {
		var m int
		fmt.Scan(&m)

		houses := make([]int, m)
		for j := 0; j < m; j++ {
			fmt.Scan(&houses[j])
		}

		var ganjil, genap []int
		for _, house := range houses {
			if house%2 == 1 {
				ganjil = append(ganjil, house)
			} else {
				genap = append(genap, house)
			}
		}

		selectionSort(ganjil, true)  
		selectionSort(genap, false)

		result := ""
		for j, angka := range ganjil {
			if j > 0 {
				result += " "
			}
			result += fmt.Sprint(angka)
		}
		for j, angka := range genap {
			if j > 0 || len(ganjil) > 0 {
				result += " "
			}
			result += fmt.Sprint(angka)
		}

		rumah[i] = result
	}

	fmt.Println("\nHasil Setelah diurutkan:")
	for _, line := range rumah {
		fmt.Println(line)
	}
}
