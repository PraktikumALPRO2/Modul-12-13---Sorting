package main

import (
	"fmt"
)

type Buku struct {
	ID        string
	Judul     string
	Penulis   string
	Penerbit  string
	Eksemplar int
	Tahun     int
	Rating    int
}

type DaftarBuku struct {
	Pustaka  []Buku
	NPustaka int
}

func DaftarkanBuku(pustaka *DaftarBuku, n int) {
	pustaka.NPustaka = n
	pustaka.Pustaka = make([]Buku, n)
	for i := 0; i < n; i++ {
		fmt.Println("Masukkan ID, Judul, Penulis, Penerbit, Eksemplar, Tahun, Rating:")
		fmt.Scanln(&pustaka.Pustaka[i].ID, &pustaka.Pustaka[i].Judul, &pustaka.Pustaka[i].Penulis,
			&pustaka.Pustaka[i].Penerbit, &pustaka.Pustaka[i].Eksemplar, &pustaka.Pustaka[i].Tahun, &pustaka.Pustaka[i].Rating)
	}
}

func CetakTerfavorit(pustaka DaftarBuku) {
	fmt.Println("\nData Buku:")
	for _, buku := range pustaka.Pustaka {
		fmt.Printf("Judul: %s, Penulis: %s, Penerbit: %s, Tahun: %d, Rating: %d\n",
			buku.Judul, buku.Penulis, buku.Penerbit, buku.Tahun, buku.Rating)
	}
}

func UrutBuku(pustaka *DaftarBuku) {
	n := pustaka.NPustaka
	for i := 1; i < n; i++ {
		key := pustaka.Pustaka[i]
		j := i - 1
		for j >= 0 && pustaka.Pustaka[j].Rating < key.Rating {
			pustaka.Pustaka[j+1] = pustaka.Pustaka[j]
			j--
		}
		pustaka.Pustaka[j+1] = key
	}
}

func Cetak5Terbaru(pustaka DaftarBuku) {
	fmt.Println("\n5 Buku dengan Rating Tertinggi:")
	for i := 0; i < 5 && i < pustaka.NPustaka; i++ {
		fmt.Printf("Judul: %s, Rating: %d\n", pustaka.Pustaka[i].Judul, pustaka.Pustaka[i].Rating)
	}
}

func CariBuku(pustaka DaftarBuku, r int) {
	left, right := 0, pustaka.NPustaka-1
	found := false
	for left <= right {
		mid := (left + right) / 2
		if pustaka.Pustaka[mid].Rating == r {
			found = true
			buku := pustaka.Pustaka[mid]
			fmt.Printf("\nBuku ditemukan:\nID: %s, Judul: %s, Penulis: %s, Penerbit: %s, Eksemplar: %d, Tahun: %d, Rating: %d\n",
				buku.ID, buku.Judul, buku.Penulis, buku.Penerbit, buku.Eksemplar, buku.Tahun, buku.Rating)
			break
		} else if pustaka.Pustaka[mid].Rating < r {
			right = mid - 1
		} else {
			left = mid + 1
		}
	}
	if !found {
		fmt.Println("Tidak ada buku dengan rating seperti itu.")
	}
}

func main() {
	var pustaka DaftarBuku
	var n int

	fmt.Println("Masukkan jumlah buku:")
	fmt.Scanln(&n)

	DaftarkanBuku(&pustaka, n)

	CetakTerfavorit(pustaka)

	UrutBuku(&pustaka)

	Cetak5Terbaru(pustaka)

	var rating int
	fmt.Println("\nMasukkan rating buku yang ingin dicari:")
	fmt.Scanln(&rating)
	CariBuku(pustaka, rating)
}
