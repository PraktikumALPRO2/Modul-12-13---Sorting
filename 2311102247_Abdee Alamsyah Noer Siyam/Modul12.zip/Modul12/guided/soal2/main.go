package main

import "fmt"

func insertionSort(data []int) {
	for i := 1; i < len(data); i++ {
		key := data[i]
		j := i - 1
		for j >= 0 && data[j] > key {
			data[j+1] = data[j]
			j--
		}
		data[j+1] = key
	}
}


func berjarakTetap(data []int) (bool, int) {
	if len(data) < 2 {
		return true, 0
	}

	spacing := data[1] - data[0]
	for i := 1; i < len(data)-1; i++ {
		if data[i+1]-data[i] != spacing {
			return false, 0
		}
	}

	return true, spacing
}

func main() {
	var input int
	var data []int

	fmt.Println("Masukkan data (akhiri dengan bilangan negatif):")
	for {
		fmt.Scan(&input)
		if input < 0 { 
			break
		}
		data = append(data, input)
	}

	sortedData := make([]int, len(data))
	copy(sortedData, data)

	insertionSort(sortedData)

	consistent, spacing := berjarakTetap(sortedData)
	
	fmt.Println("Data setelah diurutkan:", sortedData)
	if consistent {
		fmt.Printf("Data berjarak %d\n", spacing)
	} else {
		fmt.Println("Data berjarak tidak tetap")
	}
}
